#!/bin/sh

sudo semanage fcontext -a -t container_file_t '/home/student/examprep/34/dbfiles(/.*)?'

sudo restorecon -R /home/student/examprep/34/dbfiles
