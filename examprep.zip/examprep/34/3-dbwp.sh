#!/bin/sh

podman pod create --name wordpress --publish 8081:80

podman run --detach --pod wordpress \
-v /home/student/examprep/34/dbfiles:/var/lib/mysql/data \
-e MYSQL_USER=user1 \
-e MYSQL_PASSWORD=mypa55 \
-e MYSQL_DATABASE=wordpress \
-e MYSQL_ROOT_PASSWORD=r00tpa55 \
--name wpdb rhscl/mysql-57-rhel7

podman run --detach --pod wordpress \
-e WORDPRESS_DB_HOST=127.0.0.1 \
-e WORDPRESS_DB_USER=user1 \
-e WORDPRESS_DB_PASSWORD=mypa55 \
-e WORDPRESS_DB_NAME=wordpress \
-e WORDPRESS_TABLE_PREFIX=wp_ \
--name wpweb docker.io/library/wordpress
