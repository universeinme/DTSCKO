#!/bin/sh

mkdir /home/student/examprep/34/dbfiles

podman unshare chown 27:27 /home/student/examprep/34/dbfiles
