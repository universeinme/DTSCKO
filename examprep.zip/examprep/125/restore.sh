#!/bin/sh

sudo podman load -i jboss-eap-custom.tar
