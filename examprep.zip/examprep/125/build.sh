# Build Container

#!/bin/sh

sudo podman build --tag=acme/jboss-eap .
