# Run the beast

#!/bin/sh
sudo podman run -it acme/jboss-eap
