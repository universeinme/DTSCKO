#Cek running container

#!/bin/sh
sudo podman ps -a
