#!/bin/sh

sudo podman tag acme/jboss-eap:custom quay.io/maseko_priambodo/acme/jboss-eap:custom
