#!/bin/sh

sudo podman save -o jboss-eap-custom.tar acme/jboss-eap:custom
