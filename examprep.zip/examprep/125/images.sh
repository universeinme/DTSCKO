# cek images

#!/bin/sh
sudo podman images
