#!/bin/sh

sudo podman push quay.io/maseko_priambodo/acme/jboss-eap
