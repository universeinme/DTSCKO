#!/bin/sh

sudo podman tag acme/jboss-eap acme/jboss-eap:custom

